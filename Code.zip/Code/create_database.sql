-- create user

CREATE USER 'chuan'@'localhost';
GRANT ALL PRIVILEGES ON *.* TO 'chuan'@'localhost';
FLUSH PRIVILEGES;
-- create database and privileges

CREATE DATABASE button;

