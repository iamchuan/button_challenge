USE button;

-- create table customers

DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    id INT,
    signup_date DATE,
    loyalty ENUM('enrolled', 'control'),
    location VARCHAR(10),
    gender CHAR(1),
    age VARCHAR(10),
    favorite_movie_line TEXT,
    number_of_purchases INT,
    value_of_purchases INT,
    total_standard_points INT,
    total_points_redeemed INT,
    PRIMARY KEY (id)
);

-- load data into table customers

LOAD DATA LOCAL INFILE './data/customers.csv' INTO TABLE customers
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

-- create table transactions

DROP TABLE IF EXISTS transactions;

CREATE TABLE transactions (
    date DATE,
    user_id INT,
    value INT,
    point_differential INT,
    FOREIGN KEY (user_id)
        REFERENCES customers(id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

-- load data into table transactions

LOAD DATA LOCAL INFILE './data/transactions.csv' INTO TABLE transactions
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

-- purchases_view calculates standard_points and points_redeemed

DROP VIEW IF EXISTS purchases_view;

CREATE VIEW purchases_view AS
SELECT 
    t.date AS date,
    t.user_id AS user_id,
    t.value AS value, 
    FLOOR((FLOOR(t.value/100)*1000 + t.point_differential) / 101) * (c.loyalty = 'enrolled') AS standard_points,
    FLOOR((FLOOR(t.value/100)*10 - t.point_differential) * 100 / 101) * (c.loyalty = 'enrolled') AS point_redeemed
FROM transactions AS t LEFT JOIN customers AS c 
ON t.user_id = c.id;

-- purchases_aggr_view aggregates purchases_view by user_id

DROP VIEW IF EXISTS purchases_aggr_view;

CREATE VIEW purchases_aggr_view AS
SELECT user_id,
    COUNT(1) AS number_of_purchases, 
    SUM(value) AS value_of_purchases,
    SUM(standard_points) AS total_standard_points,
    SUM(point_redeemed) AS total_points_redeemed
FROM purchases_view 
GROUP BY user_id;
