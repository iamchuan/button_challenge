USE button;

-- update customers with purchase aggregation

UPDATE customers, purchases_aggr_view 
SET customers.number_of_purchases=purchases_aggr_view.number_of_purchases,
    customers.value_of_purchases=purchases_aggr_view.value_of_purchases,
    customers.total_standard_points=purchases_aggr_view.total_standard_points,
    customers.total_points_redeemed=purchases_aggr_view.total_points_redeemed
WHERE customers.id=purchases_aggr_view.user_id;